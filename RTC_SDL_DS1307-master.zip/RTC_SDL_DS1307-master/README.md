Raspberry Pi Python Library for DS1307 RTC

SwitchDoc Labs, LLC  July 21, 2014

Clone respository and run testDS1307.py to test

More Information on www.switchdoc.com

Remember to clip R1 and R2 on your Adafruit DS1307 Breakout board and connect the board to 5.0V to make it work on your.  See the full article in the August 2014 issue of Raspberry Pi Geek magazine.


